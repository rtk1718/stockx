# Search Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/ashvinmotye/pen/OdBYxP](https://codepen.io/ashvinmotye/pen/OdBYxP).

Generate a suggestion list when the user enters a search phrase based on content present on the page, in this case, a list of icons.